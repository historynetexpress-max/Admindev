import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  GraduationCap, 
  Search, 
  MessageCircle, 
  Brain, 
  Laptop, 
  MapPin,
  Clock,
  HelpCircle,
  ArrowRight,
  BookOpen,
  Award,
  Users,
  Leaf,
  BarChart3,
  Rocket,
  Globe
} from 'lucide-react';
import { quizCategories, getTotalQuestions } from '@/data/quizData';

interface HomePageProps {
  onStartQuiz: (categoryId: string, timeLimit: number) => void;
  onGoToAppBuilder: () => void;
}

const iconMap: { [key: string]: React.ElementType } = {
  GraduationCap,
  Search,
  MessageCircle,
  Brain,
  Laptop,
  MapPin,
  BookOpen,
  Leaf,
  BarChart3,
};

export function HomePage({ onStartQuiz, onGoToAppBuilder }: HomePageProps) {
  const totalQuestions = getTotalQuestions();
  const totalCategories = quizCategories.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-5"></div>
        <div className="container mx-auto px-4 py-16 relative">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <BookOpen className="w-4 h-4" />
              <span>UGC NET परीक्षा की तैयारी</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Hindi Education Quiz
              </span>
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-gray-700 mb-4">
              हिंदी शिक्षा क्विज
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              UGC NET परीक्षा के लिए व्यापक ऑनलाइन क्विज प्लेटफॉर्म। <br/>
              शिक्षण अभिक्षमता, अनुसंधान, संचार और अन्य विषयों का अभ्यास करें।
            </p>
            
            {/* Stats */}
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <div className="bg-white rounded-xl shadow-lg px-6 py-4 flex items-center gap-3">
                <div className="bg-indigo-100 p-3 rounded-lg">
                  <HelpCircle className="w-6 h-6 text-indigo-600" />
                </div>
                <div className="text-left">
                  <p className="text-2xl font-bold text-gray-900">{totalQuestions}+</p>
                  <p className="text-sm text-gray-500">प्रश्न</p>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-lg px-6 py-4 flex items-center gap-3">
                <div className="bg-purple-100 p-3 rounded-lg">
                  <BookOpen className="w-6 h-6 text-purple-600" />
                </div>
                <div className="text-left">
                  <p className="text-2xl font-bold text-gray-900">{totalCategories}</p>
                  <p className="text-sm text-gray-500">विषय</p>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-lg px-6 py-4 flex items-center gap-3">
                <div className="bg-green-100 p-3 rounded-lg">
                  <Award className="w-6 h-6 text-green-600" />
                </div>
                <div className="text-left">
                  <p className="text-2xl font-bold text-gray-900">100%</p>
                  <p className="text-sm text-gray-500">मुफ्त</p>
                </div>
              </div>
            </div>

            {/* App Builder CTA */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-6 shadow-xl">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="text-center md:text-left">
                  <h3 className="text-xl font-bold text-white mb-1 flex items-center gap-2 justify-center md:justify-start">
                    <Rocket className="w-5 h-5" />
                    अपना खुद का ऐप बनाएं
                  </h3>
                  <p className="text-indigo-100 text-sm">
                    मुफ्त में वेब ऐप बनाएं और पब्लिक URL पर डिप्लॉय करें
                  </p>
                </div>
                <Button
                  onClick={onGoToAppBuilder}
                  className="bg-white text-indigo-600 hover:bg-indigo-50 font-semibold px-6"
                >
                  <Globe className="w-4 h-4 mr-2" />
                  App Builder खोलें
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">समय-आधारित प्रैक्टिस</h3>
            <p className="text-gray-600">प्रत्येक क्विज में समय सीमा होती है जैसे वास्तविक परीक्षा में होती है</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <div className="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">विस्तृत व्याख्या</h3>
            <p className="text-gray-600">प्रत्येक प्रश्न के साथ सही उत्तर और विस्तृत व्याख्या प्राप्त करें</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-md border border-gray-100">
            <div className="bg-purple-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Award className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">स्कोर विश्लेषण</h3>
            <p className="text-gray-600">अपने प्रदर्शन का विस्तृत विश्लेषण और सुधार के सुझाव प्राप्त करें</p>
          </div>
        </div>

        {/* Categories Section */}
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-900 mb-3">क्विज श्रेणियां</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            अपनी रुचि के अनुसार किसी भी विषय का चयन करें और अभ्यास शुरू करें
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizCategories.map((category) => {
            const IconComponent = iconMap[category.icon] || BookOpen;
            return (
              <Card 
                key={category.id} 
                className="group hover:shadow-xl transition-all duration-300 border-2 border-transparent hover:border-indigo-200 cursor-pointer overflow-hidden"
                onClick={() => onStartQuiz(category.id, category.timeLimit)}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="bg-gradient-to-br from-indigo-500 to-purple-600 w-14 h-14 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                      <IconComponent className="w-7 h-7 text-white" />
                    </div>
                    <Badge variant="secondary" className="bg-indigo-50 text-indigo-700">
                      <Clock className="w-3 h-3 mr-1" />
                      {category.timeLimit} मिनट
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardTitle className="text-xl mb-1 text-gray-900 group-hover:text-indigo-600 transition-colors">
                    {category.nameHindi}
                  </CardTitle>
                  <CardTitle className="text-sm text-gray-500 mb-3 font-normal">
                    {category.name}
                  </CardTitle>
                  <CardDescription className="text-gray-600 mb-4">
                    {category.descriptionHindi}
                  </CardDescription>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="text-gray-500">
                      <HelpCircle className="w-3 h-3 mr-1" />
                      {category.questions.length} प्रश्न
                    </Badge>
                    <Button 
                      size="sm" 
                      className="bg-indigo-600 hover:bg-indigo-700 text-white group-hover:translate-x-1 transition-transform"
                    >
                      शुरू करें
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <GraduationCap className="w-6 h-6" />
                Hindi Education Quiz
              </h3>
              <p className="text-gray-400">
                UGC NET परीक्षा की तैयारी के लिए सर्वश्रेष्ठ ऑनलाइन प्लेटफॉर्म
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">विषय</h4>
              <ul className="space-y-2 text-gray-400">
                <li>शिक्षण अभिक्षमता</li>
                <li>अनुसंधान अभिक्षमता</li>
                <li>संचार</li>
                <li>तार्किक तर्क</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">टूल्स</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <button 
                    onClick={onGoToAppBuilder}
                    className="hover:text-white transition-colors flex items-center gap-2"
                  >
                    <Rocket className="w-4 h-4" />
                    App Builder
                  </button>
                </li>
                <li>UGC NET Quiz</li>
                <li>मुफ्त डिप्लॉयमेंट</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
            <p>© 2024 Hindi Education Quiz. सर्वाधिकार सुरक्षित।</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
