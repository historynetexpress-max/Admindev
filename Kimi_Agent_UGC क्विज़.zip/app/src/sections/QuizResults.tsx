import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  RotateCcw,
  Home,
  Trophy,
  Target,
  TrendingUp,
  AlertCircle,
  BookOpen
} from 'lucide-react';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { getCategoryById } from '@/data/quizData';
import type { Question } from '@/data/quizData';
import type { QuizState } from '@/types/quiz';

interface QuizResultsProps {
  quizState: QuizState;
  onRestartQuiz: () => void;
  onGoHome: () => void;
  formatTime: (seconds: number) => string;
}

interface QuestionResult {
  question: Question;
  userAnswer: number | undefined;
  isCorrect: boolean;
}

export function QuizResults({ 
  quizState, 
  onRestartQuiz, 
  onGoHome,
  formatTime 
}: QuizResultsProps) {
  const category = quizState.currentCategory ? getCategoryById(quizState.currentCategory) : null;
  const questions = category?.questions || [];
  
  // Calculate results
  const results: QuestionResult[] = questions.map(q => ({
    question: q,
    userAnswer: quizState.selectedAnswers[q.id],
    isCorrect: quizState.selectedAnswers[q.id] === q.correctAnswer
  }));

  const correctCount = results.filter(r => r.isCorrect).length;
  const incorrectCount = results.filter(r => !r.isCorrect && r.userAnswer !== undefined).length;
  const unansweredCount = results.filter(r => r.userAnswer === undefined).length;
  const totalQuestions = questions.length;
  
  const percentage = Math.round((correctCount / totalQuestions) * 100);
  
  // Calculate time taken
  const timeLimitInSeconds = (category?.timeLimit || 0) * 60;
  const timeTaken = timeLimitInSeconds - quizState.timeRemaining;
  
  // Get performance message
  const getPerformanceMessage = () => {
    if (percentage >= 80) return { message: 'उत्कृष्ट प्रदर्शन!', color: 'text-green-600', bgColor: 'bg-green-100' };
    if (percentage >= 60) return { message: 'अच्छा प्रदर्शन!', color: 'text-blue-600', bgColor: 'bg-blue-100' };
    if (percentage >= 40) return { message: 'और मेहनत की जरूरत है', color: 'text-amber-600', bgColor: 'bg-amber-100' };
    return { message: 'पुनः प्रयास करें', color: 'text-red-600', bgColor: 'bg-red-100' };
  };

  const performance = getPerformanceMessage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <Trophy className="w-6 h-6 text-indigo-600" />
              परिणाम
            </h1>
            <div className="flex gap-2">
              <Button variant="outline" onClick={onGoHome} className="flex items-center gap-2">
                <Home className="w-4 h-4" />
                होम
              </Button>
              <Button onClick={onRestartQuiz} className="bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-2">
                <RotateCcw className="w-4 h-4" />
                नया क्विज
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Score Card */}
        <Card className="mb-8 shadow-lg border-0 overflow-hidden">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-2">{category?.nameHindi}</h2>
              <p className="text-indigo-100">{category?.name}</p>
            </div>
          </div>
          <CardContent className="p-6 md:p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Score Circle */}
              <div className="text-center">
                <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full ${performance.bgColor} mb-4`}>
                  <div className="text-center">
                    <p className={`text-4xl font-bold ${performance.color}`}>{percentage}%</p>
                    <p className="text-sm text-gray-600">स्कोर</p>
                  </div>
                </div>
                <p className={`font-semibold ${performance.color}`}>{performance.message}</p>
              </div>

              {/* Stats */}
              <div className="md:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-green-50 rounded-xl p-4 text-center">
                  <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-green-700">{correctCount}</p>
                  <p className="text-sm text-green-600">सही</p>
                </div>
                <div className="bg-red-50 rounded-xl p-4 text-center">
                  <XCircle className="w-8 h-8 text-red-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-red-700">{incorrectCount}</p>
                  <p className="text-sm text-red-600">गलत</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4 text-center">
                  <AlertCircle className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-gray-700">{unansweredCount}</p>
                  <p className="text-sm text-gray-600">अनुत्तरित</p>
                </div>
                <div className="bg-blue-50 rounded-xl p-4 text-center">
                  <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-blue-700">{formatTime(timeTaken)}</p>
                  <p className="text-sm text-blue-600">समय लिया</p>
                </div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mt-8">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>प्रगति</span>
                <span>{correctCount}/{totalQuestions} सही</span>
              </div>
              <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-green-500 to-green-600 rounded-full transition-all duration-500"
                  style={{ width: `${percentage}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Performance Analysis */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="shadow-md border-0">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="bg-indigo-100 p-3 rounded-lg">
                  <Target className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">सटीकता</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {correctCount + incorrectCount > 0 
                      ? Math.round((correctCount / (correctCount + incorrectCount)) * 100) 
                      : 0}%
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="shadow-md border-0">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="bg-purple-100 p-3 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">कुल प्रश्न</p>
                  <p className="text-2xl font-bold text-gray-900">{totalQuestions}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="shadow-md border-0">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="bg-amber-100 p-3 rounded-lg">
                  <BookOpen className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">ग्रेड</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {percentage >= 90 ? 'A+' : percentage >= 80 ? 'A' : percentage >= 70 ? 'B' : percentage >= 60 ? 'C' : percentage >= 50 ? 'D' : 'F'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Question Review */}
        <Card className="shadow-lg border-0">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-600" />
              प्रश्न समीक्षा
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              {results.map((result, index) => (
                <AccordionItem key={result.question.id} value={`item-${index}`}>
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-center gap-3 text-left w-full pr-4">
                      <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                        result.isCorrect 
                          ? 'bg-green-100 text-green-700' 
                          : result.userAnswer === undefined
                          ? 'bg-gray-100 text-gray-600'
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {result.isCorrect ? (
                          <CheckCircle2 className="w-5 h-5" />
                        ) : result.userAnswer === undefined ? (
                          <AlertCircle className="w-5 h-5" />
                        ) : (
                          <XCircle className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 line-clamp-1">
                          {index + 1}. {result.question.question}
                        </p>
                      </div>
                      <Badge 
                        variant={result.isCorrect ? 'default' : result.userAnswer === undefined ? 'secondary' : 'destructive'}
                        className={`flex-shrink-0 ${
                          result.isCorrect 
                            ? 'bg-green-100 text-green-700 hover:bg-green-100' 
                            : result.userAnswer === undefined
                            ? 'bg-gray-100 text-gray-600 hover:bg-gray-100'
                            : 'bg-red-100 text-red-700 hover:bg-red-100'
                        }`}
                      >
                        {result.isCorrect ? 'सही' : result.userAnswer === undefined ? 'अनुत्तरित' : 'गलत'}
                      </Badge>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="pl-11 space-y-3">
                      <p className="font-medium text-gray-900">{result.question.question}</p>
                      <div className="space-y-2">
                        {result.question.options.map((option, optIndex) => (
                          <div 
                            key={optIndex}
                            className={`p-3 rounded-lg flex items-center gap-3 ${
                              optIndex === result.question.correctAnswer
                                ? 'bg-green-100 border border-green-300'
                                : optIndex === result.userAnswer && optIndex !== result.question.correctAnswer
                                ? 'bg-red-100 border border-red-300'
                                : 'bg-gray-50'
                            }`}
                          >
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-sm font-medium ${
                              optIndex === result.question.correctAnswer
                                ? 'bg-green-600 text-white'
                                : optIndex === result.userAnswer && optIndex !== result.question.correctAnswer
                                ? 'bg-red-600 text-white'
                                : 'bg-gray-200 text-gray-600'
                            }`}>
                              {String.fromCharCode(65 + optIndex)}
                            </div>
                            <span className={`
                              ${optIndex === result.question.correctAnswer ? 'text-green-900 font-medium' : ''}
                              ${optIndex === result.userAnswer && optIndex !== result.question.correctAnswer ? 'text-red-900' : 'text-gray-700'}
                            `}>
                              {option}
                            </span>
                            {optIndex === result.question.correctAnswer && (
                              <CheckCircle2 className="w-5 h-5 text-green-600 ml-auto" />
                            )}
                            {optIndex === result.userAnswer && optIndex !== result.question.correctAnswer && (
                              <XCircle className="w-5 h-5 text-red-600 ml-auto" />
                            )}
                          </div>
                        ))}
                      </div>
                      <div className="bg-indigo-50 p-4 rounded-lg mt-3">
                        <p className="font-semibold text-indigo-900 mb-1">व्याख्या:</p>
                        <p className="text-indigo-800">{result.question.explanation}</p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <Button 
            variant="outline" 
            onClick={onGoHome}
            className="flex items-center gap-2 px-8"
          >
            <Home className="w-5 h-5" />
            होम पेज पर जाएं
          </Button>
          <Button 
            onClick={onRestartQuiz}
            className="bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-2 px-8"
          >
            <RotateCcw className="w-5 h-5" />
            नया क्विज शुरू करें
          </Button>
        </div>
      </div>
    </div>
  );
}
