import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ChevronLeft, 
  ChevronRight, 
  Flag,
  AlertCircle,
  CheckCircle2,
  X,
  Timer
} from 'lucide-react';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { getCategoryById } from '@/data/quizData';
import type { QuizState } from '@/types/quiz';

interface QuizInterfaceProps {
  quizState: QuizState;
  onSelectAnswer: (questionId: number, answerIndex: number) => void;
  onNextQuestion: () => void;
  onPreviousQuestion: () => void;
  onCompleteQuiz: () => void;
  onExitQuiz: () => void;
  formatTime: (seconds: number) => string;
}

export function QuizInterface({ 
  quizState, 
  onSelectAnswer, 
  onNextQuestion, 
  onPreviousQuestion,
  onCompleteQuiz,
  onExitQuiz,
  formatTime 
}: QuizInterfaceProps) {
  const [showExitDialog, setShowExitDialog] = useState(false);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [timeWarning, setTimeWarning] = useState(false);

  const category = quizState.currentCategory ? getCategoryById(quizState.currentCategory) : null;
  const questions = category?.questions || [];
  const currentQuestion = questions[quizState.currentQuestionIndex];
  const totalQuestions = questions.length;
  const progress = ((quizState.currentQuestionIndex + 1) / totalQuestions) * 100;
  const answeredCount = Object.keys(quizState.selectedAnswers).length;
  const unansweredCount = totalQuestions - answeredCount;

  // Time warning effect
  useEffect(() => {
    if (quizState.timeRemaining <= 60 && quizState.timeRemaining > 0) {
      setTimeWarning(true);
    } else {
      setTimeWarning(false);
    }
  }, [quizState.timeRemaining]);

  if (!category || !currentQuestion) {
    return null;
  }

  const isFirstQuestion = quizState.currentQuestionIndex === 0;
  const isLastQuestion = quizState.currentQuestionIndex === totalQuestions - 1;
  const hasSelectedAnswer = quizState.selectedAnswers[currentQuestion.id] !== undefined;

  const handleOptionSelect = (optionIndex: number) => {
    onSelectAnswer(currentQuestion.id, optionIndex);
  };

  const getOptionStyle = (optionIndex: number) => {
    const isSelected = quizState.selectedAnswers[currentQuestion.id] === optionIndex;
    if (isSelected) {
      return 'border-indigo-500 bg-indigo-50 text-indigo-900 ring-2 ring-indigo-500 ring-offset-2';
    }
    return 'border-gray-200 bg-white text-gray-700 hover:border-indigo-300 hover:bg-indigo-50/50';
  };

  const getQuestionStatus = (index: number) => {
    const question = questions[index];
    const isAnswered = quizState.selectedAnswers[question.id] !== undefined;
    const isCurrent = index === quizState.currentQuestionIndex;
    
    if (isCurrent) return 'current';
    if (isAnswered) return 'answered';
    return 'unanswered';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setShowExitDialog(true)}
                className="text-gray-600 hover:text-gray-900"
              >
                <X className="w-5 h-5 mr-1" />
                बाहर निकलें
              </Button>
              <div className="hidden sm:block h-6 w-px bg-gray-200"></div>
              <div className="hidden sm:block">
                <h1 className="font-semibold text-gray-900">{category.nameHindi}</h1>
                <p className="text-xs text-gray-500">{category.name}</p>
              </div>
            </div>
            
            {/* Timer */}
            <div className={`flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-lg font-semibold ${
              timeWarning 
                ? 'bg-red-100 text-red-700 animate-pulse' 
                : 'bg-indigo-100 text-indigo-700'
            }`}>
              <Timer className="w-5 h-5" />
              {formatTime(quizState.timeRemaining)}
            </div>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full bg-gray-100 h-1">
          <div 
            className="bg-gradient-to-r from-indigo-500 to-purple-600 h-1 transition-all duration-300"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Question Area */}
          <div className="lg:col-span-3">
            <Card className="shadow-lg border-0">
              <CardContent className="p-6 md:p-8">
                {/* Question Header */}
                <div className="flex items-center justify-between mb-6">
                  <Badge variant="outline" className="text-indigo-600 border-indigo-200 bg-indigo-50">
                    प्रश्न {quizState.currentQuestionIndex + 1} / {totalQuestions}
                  </Badge>
                  {hasSelectedAnswer && (
                    <Badge className="bg-green-100 text-green-700 border-green-200">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      उत्तर दिया गया
                    </Badge>
                  )}
                </div>

                {/* Question */}
                <div className="mb-8">
                  <h2 className="text-xl md:text-2xl font-semibold text-gray-900 leading-relaxed">
                    {currentQuestion.question}
                  </h2>
                </div>

                {/* Options */}
                <div className="space-y-3">
                  {currentQuestion.options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleOptionSelect(index)}
                      className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 flex items-start gap-4 ${getOptionStyle(index)}`}
                    >
                      <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm ${
                        quizState.selectedAnswers[currentQuestion.id] === index
                          ? 'bg-indigo-600 text-white'
                          : 'bg-gray-100 text-gray-600'
                      }`}>
                        {String.fromCharCode(65 + index)}
                      </div>
                      <span className="text-base md:text-lg pt-0.5">{option}</span>
                    </button>
                  ))}
                </div>

                {/* Navigation Buttons */}
                <div className="flex items-center justify-between mt-8 pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={onPreviousQuestion}
                    disabled={isFirstQuestion}
                    className="flex items-center gap-2"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    पिछला
                  </Button>

                  {isLastQuestion ? (
                    <Button
                      onClick={() => setShowSubmitDialog(true)}
                      className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      क्विज समाप्त करें
                    </Button>
                  ) : (
                    <Button
                      onClick={onNextQuestion}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-2"
                    >
                      अगला
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Question Navigator */}
          <div className="lg:col-span-1">
            <Card className="shadow-lg border-0 sticky top-24">
              <CardContent className="p-4">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <Flag className="w-4 h-4" />
                  प्रश्न नेविगेटर
                </h3>
                
                {/* Stats */}
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="bg-green-50 rounded-lg p-2 text-center">
                    <p className="text-lg font-bold text-green-700">{answeredCount}</p>
                    <p className="text-xs text-green-600">उत्तर दिए</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-2 text-center">
                    <p className="text-lg font-bold text-gray-700">{unansweredCount}</p>
                    <p className="text-xs text-gray-600">बाकी</p>
                  </div>
                </div>

                {/* Question Grid */}
                <div className="grid grid-cols-5 gap-2">
                  {questions.map((_, index) => {
                    const status = getQuestionStatus(index);
                    return (
                      <button
                        key={index}
                        onClick={() => {
                          // Navigate to this question
                          const diff = index - quizState.currentQuestionIndex;
                          if (diff > 0) {
                            for (let i = 0; i < diff; i++) onNextQuestion();
                          } else if (diff < 0) {
                            for (let i = 0; i < Math.abs(diff); i++) onPreviousQuestion();
                          }
                        }}
                        className={`w-8 h-8 rounded-lg text-sm font-medium transition-all ${
                          status === 'current'
                            ? 'bg-indigo-600 text-white ring-2 ring-indigo-300'
                            : status === 'answered'
                            ? 'bg-green-100 text-green-700 border border-green-300'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                      >
                        {index + 1}
                      </button>
                    );
                  })}
                </div>

                {/* Legend */}
                <div className="mt-4 pt-4 border-t space-y-2">
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-4 h-4 bg-green-100 border border-green-300 rounded"></div>
                    <span className="text-gray-600">उत्तर दिया गया</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-4 h-4 bg-indigo-600 rounded"></div>
                    <span className="text-gray-600">वर्तमान प्रश्न</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-4 h-4 bg-gray-100 rounded"></div>
                    <span className="text-gray-600">बाकी</span>
                  </div>
                </div>

                {/* Submit Button */}
                <Button
                  onClick={() => setShowSubmitDialog(true)}
                  className="w-full mt-4 bg-green-600 hover:bg-green-700 text-white"
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  क्विज समाप्त करें
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Exit Dialog */}
      <AlertDialog open={showExitDialog} onOpenChange={setShowExitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              क्या आप निश्चित हैं?
            </AlertDialogTitle>
            <AlertDialogDescription>
              यदि आप अभी बाहर निकलते हैं, तो आपका सारा प्रगति खो जाएगा। क्या आप वाकई जारी रखना चाहते हैं?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowExitDialog(false)}>
              रद्द करें
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={onExitQuiz}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              बाहर निकलें
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Submit Dialog */}
      <AlertDialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              क्विज समाप्त करें
            </AlertDialogTitle>
            <AlertDialogDescription>
              <div className="space-y-2">
                <p>क्या आप वाकई इस क्विज को समाप्त करना चाहते हैं?</p>
                <div className="bg-gray-50 p-3 rounded-lg mt-3">
                  <p className="text-sm">
                    <span className="font-semibold">कुल प्रश्न:</span> {totalQuestions}
                  </p>
                  <p className="text-sm">
                    <span className="font-semibold">उत्तर दिए:</span> {answeredCount}
                  </p>
                  <p className="text-sm">
                    <span className="font-semibold">बाकी:</span> {unansweredCount}
                  </p>
                </div>
                {unansweredCount > 0 && (
                  <p className="text-amber-600 text-sm flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    आपके पास {unansweredCount} अनुत्तरित प्रश्न हैं!
                  </p>
                )}
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowSubmitDialog(false)}>
              रद्द करें
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={onCompleteQuiz}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              हां, समाप्त करें
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
