// Hindi Education Quiz Data - UGC NET Style
// Comprehensive question bank with 100+ questions

export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface QuizCategory {
  id: string;
  name: string;
  nameHindi: string;
  description: string;
  descriptionHindi: string;
  icon: string;
  questions: Question[];
  timeLimit: number; // in minutes
}

export const quizCategories: QuizCategory[] = [
  {
    id: "teaching-aptitude",
    name: "Teaching Aptitude",
    nameHindi: "शिक्षण अभिक्षमता",
    description: "Test your teaching skills and pedagogical knowledge",
    descriptionHindi: "अपनी शिक्षण कौशल और शैक्षिक ज्ञान का परीक्षण करें",
    icon: "GraduationCap",
    timeLimit: 25,
    questions: [
      {
        id: 1,
        question: "शिक्षण की परिभाषा क्या है?",
        options: ["केवल ज्ञान का प्रसारण", "अनुभव प्राप्त करने की प्रक्रिया", "व्यवहार में परिवर्तन लाना", "केवल परीक्षा उत्तीर्ण करना"],
        correctAnswer: 2,
        explanation: "शिक्षण वह प्रक्रिया है जो व्यक्ति के व्यवहार में वांछित परिवर्तन लाती है।"
      },
      {
        id: 2,
        question: "ब्लूम की टैक्सोनॉमी में कितने डोमेन हैं?",
        options: ["2", "3", "4", "5"],
        correctAnswer: 1,
        explanation: "ब्लूम की टैक्सोनॉमी में तीन डोमेन हैं: संज्ञानात्मक, भावनात्मक और मनो-गतिक।"
      },
      {
        id: 3,
        question: "निम्नलिखित में से कौन सा शिक्षण का उद्देश्य नहीं है?",
        options: ["ज्ञान का विकास", "कौशल का विकास", "छात्रों को डराना", "दृष्टिकोण का विकास"],
        correctAnswer: 2,
        explanation: "शिक्षण का उद्देश्य छात्रों को डराना नहीं, बल्कि उनके समग्र विकास को सुनिश्चित करना है।"
      },
      {
        id: 4,
        question: "प्रभावी शिक्षण के लिए सबसे महत्वपूर्ण क्या है?",
        options: ["अच्छी आवाज", "छात्र-अध्यापक अनुपात", "छात्रों की रुचि और जरूरतों को समझना", "केवल पाठ्यपुस्तक का उपयोग"],
        correctAnswer: 2,
        explanation: "प्रभावी शिक्षण के लिए छात्रों की रुचि और जरूरतों को समझना सबसे महत्वपूर्ण है।"
      },
      {
        id: 5,
        question: "फॉर्मेटिवiv मूल्यांकन का मुख्य उद्देश्य क्या है?",
        options: ["अंतिम ग्रेड देना", "सीखने की प्रक्रिया में सुधार करना", "छात्रों की तुलना करना", "प्रमाण पत्र देना"],
        correctAnswer: 1,
        explanation: "फॉर्मेटिवiv मूल्यांकन का मुख्य उद्देश्य सीखने की प्रक्रिया में सुधार करना है।"
      },
      {
        id: 6,
        question: "कौन सा शिक्षण विधि छात्र-केंद्रित है?",
        options: ["व्याख्यान विधि", "प्रोजेक्ट विधि", "कहानी कहने की विधि", "पाठ्यपुस्तक विधि"],
        correctAnswer: 1,
        explanation: "प्रोजेक्ट विधि एक छात्र-केंद्रित शिक्षण विधि है जहाँ छात्र सक्रिय रूप से भाग लेते हैं।"
      },
      {
        id: 7,
        question: "पावलोव का प्रयोग किससे संबंधित है?",
        options: ["शास्त्रीय अनुकूलन", "ऑपरेंट अनुकूलन", "सामाजिक सीखना", "संज्ञानात्मक सीखना"],
        correctAnswer: 0,
        explanation: "पावलोव का प्रयोग शास्त्रीय अनुकूलन (Classical Conditioning) से संबंधित है।"
      },
      {
        id: 8,
        question: "वयस्क शिक्षा का सिद्धांत किसने दिया?",
        options: ["पियाजे", "वाइगोत्स्की", "माल्कम नोल्स", "ब्रूनर"],
        correctAnswer: 2,
        explanation: "वयस्क शिक्षा (Andragogy) का सिद्धांत माल्कम नोल्स ने दिया।"
      },
      {
        id: 9,
        question: "माइक्रो टीचिंग में कितने चरण होते हैं?",
        options: ["3", "4", "5", "6"],
        correctAnswer: 2,
        explanation: "माइक्रो टीचिंग में 5 चरण होते हैं: योजना, अभ्यास, प्रतिक्रिया, पुनरावृत्ति और पुन: अभ्यास।"
      },
      {
        id: 10,
        question: "निम्नलिखित में से कौन सा मूल्यांकन का प्रकार नहीं है?",
        options: ["नैदानिक मूल्यांकन", "संरचनात्मक मूल्यांकन", "अनुमानी मूल्यांकन", "स्वयं मूल्यांकन"],
        correctAnswer: 1,
        explanation: "संरचनात्मक मूल्यांकन मूल्यांकन का एक मान्य प्रकार नहीं है।"
      },
      {
        id: 11,
        question: "कोहलबर्ग के नैतिक विकास के सिद्धांत में कितने स्तर हैं?",
        options: ["2", "3", "4", "6"],
        correctAnswer: 1,
        explanation: "कोहलबर्ग के नैतिक विकास के सिद्धांत में 3 स्तर हैं: पूर्व-पारंपरिक, पारंपरिक और उत्तर-पारंपरिक।"
      },
      {
        id: 12,
        question: "पियाजे के संज्ञानात्मक विकास सिद्धांत में कितने चरण हैं?",
        options: ["3", "4", "5", "6"],
        correctAnswer: 1,
        explanation: "पियाजे के सिद्धांत में 4 चरण हैं: संवेदी-गामक, पूर्व-संक्रियात्मक, संक्रियात्मक और औपचारिक संक्रियात्मक।"
      },
      {
        id: 13,
        question: "वाइगोत्स्की का प्रसिद्ध सिद्धांत क्या है?",
        options: ["संज्ञानात्मक विकास", "सामाजिक संरचनावाद", "नैतिक विकास", "व्यक्तित्व विकास"],
        correctAnswer: 1,
        explanation: "वाइगोत्स्की ने सामाजिक संरचनावाद (Social Constructivism) का सिद्धांत दिया।"
      },
      {
        id: 14,
        question: "ZPD का पूर्ण रूप क्या है?",
        options: ["Zone of Personal Development", "Zone of Proximal Development", "Zone of Potential Development", "Zone of Practical Development"],
        correctAnswer: 1,
        explanation: "ZPD का पूर्ण रूप Zone of Proximal Development है, जिसे वाइगोत्स्की ने दिया।"
      },
      {
        id: 15,
        question: "स्कीनर का प्रयोग किससे संबंधित है?",
        options: ["शास्त्रीय अनुकूलन", "ऑपरेंट अनुकूलन", "सामाजिक सीखना", "अवलोकनात्मक सीखना"],
        correctAnswer: 1,
        explanation: "स्कीनर का प्रयोग ऑपरेंट अनुकूलन (Operant Conditioning) से संबंधित है।"
      },
      {
        id: 16,
        question: "निम्नलिखित में से कौन सा सीखने का प्रकार नहीं है?",
        options: ["अवलोकनात्मक सीखना", "अनुकूलन", "संज्ञानात्मक सीखना", "यादृच्छिक सीखना"],
        correctAnswer: 3,
        explanation: "यादृच्छिक सीखना (Random Learning) सीखने का एक मान्य प्रकार नहीं है।"
      },
      {
        id: 17,
        question: "गैग्ने ने सीखने के कितने प्रकार बताए हैं?",
        options: ["5", "6", "8", "10"],
        correctAnswer: 2,
        explanation: "गैग्ने ने सीखने के 8 प्रकार बताए हैं, जो सिग्नल सीखने से समस्या समाधान तक हैं।"
      },
      {
        id: 18,
        question: "ब्रूनर के अनुसार ज्ञान प्रस्तुति के कितने मोड हैं?",
        options: ["2", "3", "4", "5"],
        correctAnswer: 1,
        explanation: "ब्रूनर के अनुसार ज्ञान प्रस्तुति के 3 मोड हैं: एनएक्टिव, आइकॉनिक और सिम्बॉलिक।"
      },
      {
        id: 19,
        question: "मास्लो की आवश्यकताओं की श्रेणी में कितने स्तर हैं?",
        options: ["3", "4", "5", "7"],
        correctAnswer: 2,
        explanation: "मास्लो की आवश्यकताओं की श्रेणी में 5 स्तर हैं: शारीरिक, सुरक्षा, सामाजिक, सम्मान और आत्म-वास्तविकरण।"
      },
      {
        id: 20,
        question: "निम्नलिखित में से कौन सा शिक्षण सहायक उपकरण नहीं है?",
        options: ["प्रोजेक्टर", "चार्ट", "पाठ्यपुस्तक", "छात्र की उपस्थिति"],
        correctAnswer: 3,
        explanation: "छात्र की उपस्थिति शिक्षण सहायक उपकरण नहीं है, बल्कि शिक्षण प्रक्रिया का एक घटक है।"
      }
    ]
  },
  {
    id: "research-aptitude",
    name: "Research Aptitude",
    nameHindi: "अनुसंधान अभिक्षमता",
    description: "Test your research methodology and analytical skills",
    descriptionHindi: "अपनी अनुसंधान पद्धति और विश्लेषणात्मक कौशल का परीक्षण करें",
    icon: "Search",
    timeLimit: 25,
    questions: [
      {
        id: 1,
        question: "अनुसंधान का अर्थ है?",
        options: ["केवल जानकारी इकट्ठा करना", "समस्या का समाधान खोजना", "केवल पुस्तकें पढ़ना", "केवल लेख लिखना"],
        correctAnswer: 1,
        explanation: "अनुसंधान एक व्यवस्थित प्रक्रिया है जिसके द्वारा समस्या का समाधान खोजा जाता है।"
      },
      {
        id: 2,
        question: "मूल अनुसंधान को क्या कहा जाता है?",
        options: ["अनुप्रयुक्त अनुसंधान", "शुद्ध अनुसंधान", "कार्यात्मक अनुसंधान", "वर्णनात्मक अनुसंधान"],
        correctAnswer: 1,
        explanation: "मूल अनुसंधान को शुद्ध अनुसंधान (Pure Research) भी कहा जाता है।"
      },
      {
        id: 3,
        question: "निम्नलिखित में से कौन सा अनुसंधान का प्रकार नहीं है?",
        options: ["प्रयोगात्मक अनुसंधान", "वर्णनात्मक अनुसंधान", "काल्पनिक अनुसंधान", "ऐतिहासिक अनुसंधान"],
        correctAnswer: 2,
        explanation: "काल्पनिक अनुसंधान अनुसंधान का एक मान्य प्रकार नहीं है।"
      },
      {
        id: 4,
        question: "सर्वेक्षण विधि में किसका उपयोग होता है?",
        options: ["केवल प्रश्नावली", "केवल साक्षात्कार", "प्रश्नावली और साक्षात्कार दोनों", "केवल प्रेक्षण"],
        correctAnswer: 2,
        explanation: "सर्वेक्षण विधि में प्रश्नावली और साक्षात्कार दोनों का उपयोग होता है।"
      },
      {
        id: 5,
        question: "नमूना (Sample) क्या है?",
        options: ["संपूर्ण जनसंख्या", "जनसंख्या का एक भाग", "केवल छात्र", "केवल शिक्षक"],
        correctAnswer: 1,
        explanation: "नमूना जनसंख्या का एक प्रतिनिधि भाग होता है जिससे डेटा एकत्र किया जाता है।"
      },
      {
        id: 6,
        question: "शून्य परिकल्पना (Null Hypothesis) क्या है?",
        options: ["परिकल्पना जो स्वीकार की जाती है", "परिकल्पना जो अस्वीकार की जाती है", "परिकल्पना जो कहती है कोई अंतर नहीं है", "परिकल्पना जो कहती है अंतर है"],
        correctAnswer: 2,
        explanation: "शून्य परिकल्पना वह परिकल्पना है जो कहती है कि कोई महत्वपूर्ण अंतर या संबंध नहीं है।"
      },
      {
        id: 7,
        question: "t-टेस्ट का उपयोग कब किया जाता है?",
        options: ["तीन या अधिक समूहों की तुलना के लिए", "दो समूहों की तुलना के लिए", "सहसंबंध के लिए", "प्रतिशत के लिए"],
        correctAnswer: 1,
        explanation: "t-टेस्ट का उपयोग दो समूहों की औसत तुलना के लिए किया जाता है।"
      },
      {
        id: 8,
        question: "मानक विचलन (Standard Deviation) क्या मापता है?",
        options: ["केंद्रीय प्रवृत्ति", "प्रसरण", "सहसंबंध", "प्रतिगमन"],
        correctAnswer: 1,
        explanation: "मानक विचलन डेटा के प्रसरण (dispersion) या फैलाव को मापता है।"
      },
      {
        id: 9,
        question: "निम्नलिखित में से कौन सा गुणात्मक अनुसंधान का तरीका नहीं है?",
        options: ["मामला अध्ययन", "जीवनी विधि", "प्रयोग विधि", "प्रतिभागी प्रेक्षण"],
        correctAnswer: 2,
        explanation: "प्रयोग विधि मुख्य रूप से मात्रात्मक अनुसंधान की विधि है।"
      },
      {
        id: 10,
        question: "अनुसंधान प्रबंधा (Research Proposal) में क्या शामिल नहीं होता?",
        options: ["समस्या का कथन", "साहित्य समीक्षा", "अंतिम परिणाम", "कार्यप्रणाली"],
        correctAnswer: 2,
        explanation: "अनुसंधान प्रबंधा में अंतिम परिणाम शामिल नहीं होते क्योंकि अनुसंधान अभी शुरू होना बाकी है।"
      },
      {
        id: 11,
        question: "ANOVA का पूर्ण रूप क्या है?",
        options: ["Analysis of Variance", "Analysis of Variation", "Analytical Variance", "Annual Variance"],
        correctAnswer: 0,
        explanation: "ANOVA का पूर्ण रूप Analysis of Variance है, जो तीन या अधिक समूहों की तुलना के लिए उपयोग होता है।"
      },
      {
        id: 12,
        question: "सहसंबंध गुणांक (Correlation Coefficient) का मान कहाँ से कहाँ तक होता है?",
        options: ["0 से 1", "-1 से 0", "-1 से +1", "0 से अनंत"],
        correctAnswer: 2,
        explanation: "सहसंबंध गुणांक का मान -1 से +1 के बीच होता है, जहाँ -1 पूर्ण नकारात्मक और +1 पूर्ण सकारात्मक संबंध दर्शाता है।"
      },
      {
        id: 13,
        question: "निम्नलिखित में से कौन सा प्रायिकता नमूनाकरण (Probability Sampling) का प्रकार नहीं है?",
        options: ["सरल यादृच्छिक नमूनाकरण", "स्तरीय नमूनाकरण", "झुकावपूर्ण नमूनाकरण", "समूह नमूनाकरण"],
        correctAnswer: 2,
        explanation: "झुकावपूर्ण नमूनाकरण (Convenience Sampling) एक अप्रायिकता नमूनाकरण है।"
      },
      {
        id: 14,
        question: "माध्य, मध्यिका और बहुलक में से कौन सा केंद्रीय प्रवृत्ति का सर्वोत्तम माप है?",
        options: ["माध्य", "मध्यिका", "बहुलक", "सभी समान हैं"],
        correctAnswer: 0,
        explanation: "माध्य (Mean) केंद्रीय प्रवृत्ति का सबसे स्थिर और व्यापक रूप से उपयोग किया जाने वाला माप है।"
      },
      {
        id: 15,
        question: "प्रश्नावली (Questionnaire) और अनुसूची (Schedule) में मुख्य अंतर क्या है?",
        options: ["प्रश्नों की संख्या", "साक्षात्कारकर्ता की उपस्थिति", "प्रश्नों का प्रकार", "उत्तरदाताओं की संख्या"],
        correctAnswer: 1,
        explanation: "अनुसूची में साक्षात्कारकर्ता उपस्थित होता है, जबकि प्रश्नावली स्व-प्रशासित होती है।"
      },
      {
        id: 16,
        question: "क्रॉस-सेक्शनल अध्ययन क्या है?",
        options: ["एक ही समय में विभिन्न समूहों का अध्ययन", "एक समूह का लंबे समय तक अध्ययन", "प्रयोगात्मक अध्ययन", "ऐतिहासिक अध्ययन"],
        correctAnswer: 0,
        explanation: "क्रॉस-सेक्शनल अध्ययन में एक ही समय में विभिन्न आयु वर्ग या समूहों का अध्ययन किया जाता है।"
      },
      {
        id: 17,
        question: "लॉन्गीट्यूडिनल अध्ययन क्या है?",
        options: ["एक ही समय में विभिन्न समूहों का अध्ययन", "एक समूह का लंबे समय तक अध्ययन", "प्रयोगात्मक अध्ययन", "ऐतिहासिक अध्ययन"],
        correctAnswer: 1,
        explanation: "लॉन्गीट्यूडिनल अध्ययन में एक ही समूह का लंबे समय तक अध्ययन किया जाता है।"
      },
      {
        id: 18,
        question: "निम्नलिखित में से कौन सा मानकीकृत परीक्षण नहीं है?",
        options: ["TAT", "Rorschach", "Interview", "MMPI"],
        correctAnswer: 2,
        explanation: "Interview एक मानकीकृत परीक्षण नहीं है, बल्कि एक अनुसंधान विधि है।"
      },
      {
        id: 19,
        question: "पीयरसन का सहसंबंध गुणांक किसके बीच संबंध मापता है?",
        options: ["दो गुणात्मक चर", "दो मात्रात्मक चर", "एक गुणात्मक और एक मात्रात्मक चर", "तीन या अधिक चर"],
        correctAnswer: 1,
        explanation: "पीयरसन का सहसंबंध गुणांक दो मात्रात्मक (continuous) चरों के बीच संबंध मापता है।"
      },
      {
        id: 20,
        question: "स्पीयरमैन का रैंक ऑर्डर सहसंबंध किसके लिए उपयोग होता है?",
        options: ["मात्रात्मक डेटा", "गुणात्मक डेटा", "ऑर्डिनल डेटा", "सभी प्रकार के डेटा"],
        correctAnswer: 2,
        explanation: "स्पीयरमैन का रैंक ऑर्डर सहसंबंध ऑर्डिनल (ranked) डेटा के लिए उपयोग होता है।"
      }
    ]
  },
  {
    id: "communication",
    name: "Communication",
    nameHindi: "संचार",
    description: "Test your communication skills and knowledge",
    descriptionHindi: "अपने संचार कौशल और ज्ञान का परीक्षण करें",
    icon: "MessageCircle",
    timeLimit: 20,
    questions: [
      {
        id: 1,
        question: "संचार की प्रक्रिया में कितने तत्व होते हैं?",
        options: ["3", "5", "7", "9"],
        correctAnswer: 2,
        explanation: "संचार की प्रक्रिया में 7 तत्व होते हैं: प्रेषक, संदेश, एन्कोडिंग, चैनल, डिकोडिंग, प्राप्तकर्ता और प्रतिक्रिया।"
      },
      {
        id: 2,
        question: "अशब्दीय संचार (Non-verbal Communication) में क्या शामिल है?",
        options: ["केवल भाषा", "हाव-भाव, मुद्राएं और दृष्टि संपर्क", "केवल लिखित संदेश", "केवल फोन कॉल"],
        correctAnswer: 1,
        explanation: "अशब्दीय संचार में हाव-भाव, मुद्राएं, दृष्टि संपर्क और शारीरिक भाषा शामिल है।"
      },
      {
        id: 3,
        question: "संचार का सबसे प्रभावी रूप कौन सा है?",
        options: ["एकतरफा संचार", "द्वितीयक संचार", "द्विपक्षीय संचार", "अप्रत्यक्ष संचार"],
        correctAnswer: 2,
        explanation: "द्विपक्षीय संचार सबसे प्रभावी है क्योंकि इसमें प्रतिक्रिया और संवाद होता है।"
      },
      {
        id: 4,
        question: "शोर (Noise) in संचार refers to?",
        options: ["केवल आवाज", "संदेश में बाधा", "केवल संगीत", "केवल बातचीत"],
        correctAnswer: 1,
        explanation: "शोर संचार में किसी भी प्रकार की बाधा को कहते है जो संदेश को स्पष्ट रूप से पहुंचने से रोकती है।"
      },
      {
        id: 5,
        question: "कौन सा संचार का माध्यम नहीं है?",
        options: ["टेलीफोन", "ईमेल", "विचार", "पत्र"],
        correctAnswer: 2,
        explanation: "विचार संचार का माध्यम नहीं है, बल्कि संचार की सामग्री हो सकती है।"
      },
      {
        id: 6,
        question: "संचार के शannon-Weaver मॉडल में कितने तत्व हैं?",
        options: ["3", "5", "7", "6"],
        correctAnswer: 1,
        explanation: "शannon-Weaver मॉडल में 5 तत्व हैं: सूचना स्रोत, ट्रांसमीटर, चैनल, रिसीवर और गंतव्य।"
      },
      {
        id: 7,
        question: "Lasswell का संचार मॉडल क्या है?",
        options: ["Who says what in which channel to whom with what effect", "Sender-Message-Receiver", "Encoding-Decoding", "Input-Process-Output"],
        correctAnswer: 0,
        explanation: "Lasswell का मॉडल है: 'Who says what in which channel to whom with what effect'"
      },
      {
        id: 8,
        question: "संचार की बाधा (Barrier) कौन सी नहीं है?",
        options: ["भौतिक बाधा", "भाषाई बाधा", "सामाजिक बाधा", "संचार माध्यम"],
        correctAnswer: 3,
        explanation: "संचार माध्यम बाधा नहीं है, बल्कि संचार का एक घटक है।"
      },
      {
        id: 9,
        question: "अंतःवैयक्तिक संचार (Intrapersonal Communication) क्या है?",
        options: ["दो व्यक्तियों के बीच संचार", "स्वयं से संचार", "समूह में संचार", "सार्वजनिक संचार"],
        correctAnswer: 1,
        explanation: "अंतःवैयक्तिक संचार स्वयं से संचार है, जैसे विचार करना या आत्म-प्रतिबिंब।"
      },
      {
        id: 10,
        question: "समूह संचार (Group Communication) की विशेषता क्या है?",
        options: ["केवल एकतरफा संचार", "बहुत से लोगों के बीच संचार", "केवल लिखित संचार", "केवल औपचारिक संचार"],
        correctAnswer: 1,
        explanation: "समूह संचार में बहुत से लोगों के बीच संचार होता है, जिसमें बातचीत और चर्चा शामिल है।"
      },
      {
        id: 11,
        question: "संचार में प्रतिक्रिया (Feedback) का महत्व क्या है?",
        options: ["संदेश भेजना", "संदेश प्राप्त करना", "संचार प्रक्रिया की पुष्टि", "शोर कम करना"],
        correctAnswer: 2,
        explanation: "प्रतिक्रिया संचार प्रक्रिया की पुष्टि करती है और सुनिश्चित करती है कि संदेश सही ढंग से समझा गया।"
      },
      {
        id: 12,
        question: "कौन सा संचार का स्तर नहीं है?",
        options: ["अंतःवैयक्तिक", "अंतर्वैयक्तिक", "सामूहिक", "असंबद्ध"],
        correctAnswer: 3,
        explanation: "असंबद्ध (Unrelated) संचार का कोई स्तर नहीं है।"
      },
      {
        id: 13,
        question: "मास मीडिया (Mass Media) का मुख्य उद्देश्य क्या है?",
        options: ["केवल मनोरंजन", "केवल शिक्षा", "बड़ी संख्या में लोगों तक संदेश पहुंचाना", "केवल विज्ञापन"],
        correctAnswer: 2,
        explanation: "मास मीडिया का मुख्य उद्देश्य बड़ी संख्या में लोगों तक संदेश पहुंचाना है।"
      },
      {
        id: 14,
        question: "निम्नलिखित में से कौन सा मास मीडिया नहीं है?",
        options: ["टेलीविजन", "अखबार", "पर्सनल लेटर", "रेडियो"],
        correctAnswer: 2,
        explanation: "पर्सनल लेटर (व्यक्तिगत पत्र) मास मीडिया नहीं है, बल्कि व्यक्तिगत संचार है।"
      },
      {
        id: 15,
        question: "संचार में संदेश (Message) क्या है?",
        options: ["संचार का माध्यम", "संचार की सामग्री", "संचार का स्रोत", "संचार की प्रतिक्रिया"],
        correctAnswer: 1,
        explanation: "संदेश संचार की सामग्री या जानकारी है जो प्रेषक से प्राप्तकर्ता तक भेजी जाती है।"
      }
    ]
  },
  {
    id: "logical-reasoning",
    name: "Logical Reasoning",
    nameHindi: "तार्किक तर्क",
    description: "Test your logical and analytical thinking",
    descriptionHindi: "अपने तार्किक और विश्लेषणात्मक चिंतन का परीक्षण करें",
    icon: "Brain",
    timeLimit: 20,
    questions: [
      {
        id: 1,
        question: "यदि सभी A, B हैं और सभी B, C हैं, तो?",
        options: ["सभी C, A हैं", "कुछ A, C हैं", "सभी A, C हैं", "कोई A, C नहीं है"],
        correctAnswer: 2,
        explanation: "यदि सभी A, B हैं और सभी B, C हैं, तो सभी A, C होंगे (परिवर्तन सिद्धांत)।"
      },
      {
        id: 2,
        question: "निम्नलिखित श्रृंखला में अगली संख्या क्या होगी: 2, 6, 12, 20, 30, ?",
        options: ["36", "40", "42", "44"],
        correctAnswer: 2,
        explanation: "श्रृंखला n(n+1) का पालन करती है: 1×2=2, 2×3=6, 3×4=12, 4×5=20, 5×6=30, 6×7=42"
      },
      {
        id: 3,
        question: "यदि P का अर्थ '+', Q का अर्थ '-', R का अर्थ '×' और S का अर्थ '÷' है, तो 16 R 3 P 4 Q 2 = ?",
        options: ["50", "48", "46", "44"],
        correctAnswer: 0,
        explanation: "16 × 3 + 4 - 2 = 48 + 4 - 2 = 50"
      },
      {
        id: 4,
        question: "किसी कोड में, 'COMPUTER' को 'RFUVQNPC' लिखा जाता है, तो 'MEDICINE' को कैसे लिखा जाएगा?",
        options: ["EOJDJEFM", "EOJDJELM", "EMJDJEFM", "EOJDLEFM"],
        correctAnswer: 0,
        explanation: "प्रत्येक अक्षर को अगले अक्षर से बदला गया है: C→D, O→P, M→N, P→Q, U→V, T→U, E→F, R→S, लेकिन उल्टे क्रम में।"
      },
      {
        id: 5,
        question: "5 लोग एक पंक्ति में बैठे हैं। A, B के बगल में है। C, D के बगल में है। यदि E सबसे बाईं ओर है, तो कौन बीच में हो सकता है?",
        options: ["A", "B", "C", "D"],
        correctAnswer: 2,
        explanation: "E _ _ _ _ में, यदि A, B के बगल में और C, D के बगल में हैं, तो C बीच में हो सकता है।"
      },
      {
        id: 6,
        question: "यदि कल बुधवार के बाद का दिन था, तो आज कौन सा दिन है?",
        options: ["शुक्रवार", "गुरुवार", "शनिवार", "रविवार"],
        correctAnswer: 0,
        explanation: "कल बुधवार के बाद गुरुवार था, इसलिए आज शुक्रवार है।"
      },
      {
        id: 7,
        question: "निम्नलिखित में से भिन्न को पहचानें: 2, 3, 5, 9, 11",
        options: ["2", "3", "9", "11"],
        correctAnswer: 2,
        explanation: "9 एक अभाज्य संख्या नहीं है, जबकि अन्य सभी अभाज्य संख्याएं हैं।"
      },
      {
        id: 8,
        question: "यदि BOOK को 43 और PEN को 35 लिखा जाता है, तो COPY को क्या लिखा जाएगा?",
        options: ["48", "52", "59", "63"],
        correctAnswer: 2,
        explanation: "अक्षरों के क्रमांक का योग: B(2)+O(15)+O(15)+K(11)=43, C(3)+O(15)+P(16)+Y(25)=59"
      },
      {
        id: 9,
        question: "A, B की बहन है। C, B का भाई है। D, A का पिता है। तो C, D का क्या लगेगा?",
        options: ["पुत्र", "पोता", "भतीजा", "दामाद"],
        correctAnswer: 0,
        explanation: "C, B का भाई है और B, A का भाई/बहन है, इसलिए C भी A का भाई है और D का पुत्र।"
      },
      {
        id: 10,
        question: "श्रृंखला पूर्ण करें: AZ, BY, CX, DW, ?",
        options: ["EV", "FU", "EV", "EU"],
        correctAnswer: 0,
        explanation: "पहला अक्षर A, B, C, D, E और दूसरा Z, Y, X, W, V में घटता है।"
      },
      {
        id: 11,
        question: "यदि सभी फूल पेड़ हैं, सभी पेड़ जंगल हैं, और कुछ जंगल पहाड़ हैं, तो?",
        options: ["सभी फूल पहाड़ हैं", "कुछ फूल पहाड़ हैं", "कोई फूल पहाड़ नहीं", "निश्चित रूप से कुछ नहीं कहा जा सकता"],
        correctAnswer: 3,
        explanation: "दिए गए कथनों से फूल और पहाड़ के बीच निश्चित संबंध स्थापित नहीं होता।"
      },
      {
        id: 12,
        question: "निम्नलिखित अनुपातिक संबंध में प्रश्न चिह्न की जगह क्या आएगा: 8 : 28 :: 27 : ?",
        options: ["64", "85", "91", "108"],
        correctAnswer: 1,
        explanation: "8 = 2³, 28 = 3³+1; 27 = 3³, इसलिए 4³+1 = 65, लेकिन 85 = 4³+21, वैकल्पिक रूप से 3×9+1=28, 9×9+4=85"
      },
      {
        id: 13,
        question: "यदि किसी निश्चित कोड में, 'MANGO' को 'OCKPI' लिखा जाता है, तो 'GRAPE' को क्या लिखा जाएगा?",
        options: ["ITCRG", "ITCTG", "ITCRH", "ITCSG"],
        correctAnswer: 0,
        explanation: "प्रत्येक अक्षर को +2 से बदला गया है: M→O, A→C, N→P, G→I, O→Q; G→I, R→T, A→C, P→R, E→G"
      },
      {
        id: 14,
        question: "6 व्यक्ति A, B, C, D, E, F एक गोल मेज पर बैठे हैं। A, B के दाईं ओर है। C, D के बाईं ओर है। E, A के सामने है। तो F कहाँ बैठा है?",
        options: ["B के सामने", "C के सामने", "D के सामने", "E के सामने"],
        correctAnswer: 1,
        explanation: "गोल मेज पर व्यवस्था करने पर F, C के सामने बैठा होगा।"
      },
      {
        id: 15,
        question: "निम्नलिखित संख्या श्रृंखला में अगली संख्या क्या होगी: 1, 1, 2, 3, 5, 8, 13, ?",
        options: ["18", "19", "21", "23"],
        correctAnswer: 2,
        explanation: "यह फाइबोनैचि श्रृंखला है जहाँ प्रत्येक संख्या पिछली दो संख्याओं का योग है: 8+13=21"
      }
    ]
  },
  {
    id: "ict",
    name: "Information & Communication Technology",
    nameHindi: "सूचना और संचार प्रौद्योगिकी",
    description: "Test your ICT knowledge and digital skills",
    descriptionHindi: "अपने आईसीटी ज्ञान और डिजिटल कौशल का परीक्षण करें",
    icon: "Laptop",
    timeLimit: 20,
    questions: [
      {
        id: 1,
        question: "CPU का पूर्ण रूप क्या है?",
        options: ["Central Processing Unit", "Computer Processing Unit", "Central Process Unit", "Central Processor Unit"],
        correctAnswer: 0,
        explanation: "CPU का पूर्ण रूप Central Processing Unit है, जो कंप्यूटर का मस्तिष्क है।"
      },
      {
        id: 2,
        question: "1 GB में कितने MB होते हैं?",
        options: ["100 MB", "1024 MB", "1000 MB", "512 MB"],
        correctAnswer: 1,
        explanation: "1 GB (Gigabyte) में 1024 MB (Megabytes) होते हैं।"
      },
      {
        id: 3,
        question: "निम्नलिखित में से कौन सा ऑपरेटिंग सिस्टम नहीं है?",
        options: ["Windows", "Linux", "Microsoft Office", "macOS"],
        correctAnswer: 2,
        explanation: "Microsoft Office एक एप्लिकेशन सूट है, न कि ऑपरेटिंग सिस्टम।"
      },
      {
        id: 4,
        question: "HTML का पूर्ण रूप क्या है?",
        options: ["Hyper Text Markup Language", "High Text Markup Language", "Hyper Text Making Language", "Hyper Text Markup Link"],
        correctAnswer: 0,
        explanation: "HTML का पूर्ण रूप Hyper Text Markup Language है, जो वेब पेज बनाने के लिए उपयोग होता है।"
      },
      {
        id: 5,
        question: "निम्नलिखित में से कौन सा क्लाउड स्टोरेज सेवा नहीं है?",
        options: ["Google Drive", "Dropbox", "Microsoft Word", "OneDrive"],
        correctAnswer: 2,
        explanation: "Microsoft Word एक वर्ड प्रोसेसिंग एप्लिकेशन है, न कि क्लाउड स्टोरेज सेवा।"
      },
      {
        id: 6,
        question: "RAM का पूर्ण रूप क्या है?",
        options: ["Random Access Memory", "Read Access Memory", "Random Available Memory", "Read Available Memory"],
        correctAnswer: 0,
        explanation: "RAM का पूर्ण रूप Random Access Memory है, जो अस्थायी मेमोरी है।"
      },
      {
        id: 7,
        question: "ROM का पूर्ण रूप क्या है?",
        options: ["Read Only Memory", "Random Only Memory", "Read Output Memory", "Random Output Memory"],
        correctAnswer: 0,
        explanation: "ROM का पूर्ण रूप Read Only Memory है, जो स्थायी मेमोरी है।"
      },
      {
        id: 8,
        question: "निम्नलिखित में से कौन सा वायरस नहीं है?",
        options: ["Trojan", "Worm", "Firewall", "Ransomware"],
        correctAnswer: 2,
        explanation: "Firewall एक सुरक्षा प्रणाली है, न कि वायरस।"
      },
      {
        id: 9,
        question: "URL का पूर्ण रूप क्या है?",
        options: ["Uniform Resource Locator", "Universal Resource Locator", "Uniform Resource Link", "Universal Resource Link"],
        correctAnswer: 0,
        explanation: "URL का पूर्ण रूप Uniform Resource Locator है, जो वेब पते का पता है।"
      },
      {
        id: 10,
        question: "HTTP का पूर्ण रूप क्या है?",
        options: ["Hyper Text Transfer Protocol", "High Text Transfer Protocol", "Hyper Text Transmission Protocol", "High Text Transmission Protocol"],
        correctAnswer: 0,
        explanation: "HTTP का पूर्ण रूप Hyper Text Transfer Protocol है, जो वेब पर डेटा ट्रांसफर के लिए उपयोग होता है।"
      },
      {
        id: 11,
        question: "निम्नलिखित में से कौन सा प्रोग्रामिंग भाषा नहीं है?",
        options: ["Python", "Java", "HTML", "C++"],
        correctAnswer: 2,
        explanation: "HTML एक मार्कअप भाषा है, न कि प्रोग्रामिंग भाषा।"
      },
      {
        id: 12,
        question: "IP का पूर्ण रूप क्या है?",
        options: ["Internet Protocol", "Internet Process", "Internal Protocol", "Internal Process"],
        correctAnswer: 0,
        explanation: "IP का पूर्ण रूप Internet Protocol है, जो इंटरनेट पर डिवाइसों को पहचानने के लिए उपयोग होता है।"
      },
      {
        id: 13,
        question: "DNS का पूर्ण रूप क्या है?",
        options: ["Domain Name System", "Domain Network System", "Digital Name System", "Digital Network System"],
        correctAnswer: 0,
        explanation: "DNS का पूर्ण रूप Domain Name System है, जो डोमेन नामों को IP पतों में बदलता है।"
      },
      {
        id: 14,
        question: "SSD का पूर्ण रूप क्या है?",
        options: ["Solid State Drive", "Solid Storage Drive", "State Solid Drive", "Storage State Drive"],
        correctAnswer: 0,
        explanation: "SSD का पूर्ण रूप Solid State Drive है, जो फ्लैश मेमोरी पर आधारित स्टोरेज डिवाइस है।"
      },
      {
        id: 15,
        question: "निम्नलिखित में से कौन सा सोशल मीडिया प्लेटफॉर्म नहीं है?",
        options: ["Facebook", "Twitter", "Microsoft Excel", "Instagram"],
        correctAnswer: 2,
        explanation: "Microsoft Excel एक स्प्रेडशीट एप्लिकेशन है, न कि सोशल मीडिया प्लेटफॉर्म।"
      }
    ]
  },
  {
    id: "indian-society",
    name: "Indian Society & Culture",
    nameHindi: "भारतीय समाज और संस्कृति",
    description: "Test your knowledge about Indian society and cultural heritage",
    descriptionHindi: "भारतीय समाज और सांस्कृतिक विरासत के बारे में अपने ज्ञान का परीक्षण करें",
    icon: "MapPin",
    timeLimit: 25,
    questions: [
      {
        id: 1,
        question: "भारत की जनगणना कितने वर्षों में होती है?",
        options: ["5 वर्ष", "10 वर्ष", "15 वर्ष", "20 वर्ष"],
        correctAnswer: 1,
        explanation: "भारत की जनगणना प्रत्येक 10 वर्षों में होती है।"
      },
      {
        id: 2,
        question: "भारत में कितनी अनुसूचित भाषाएं हैं?",
        options: ["18", "22", "25", "15"],
        correctAnswer: 1,
        explanation: "भारत की संविधान की आठवीं अनुसूची में 22 अनुसूचित भाषाएं हैं।"
      },
      {
        id: 3,
        question: "भारत में साक्षरता दर (2011 की जनगणना के अनुसार) क्या थी?",
        options: ["64.8%", "74.0%", "82.5%", "91.2%"],
        correctAnswer: 1,
        explanation: "2011 की जनगणना के अनुसार भारत की साक्षरता दर 74.0% थी।"
      },
      {
        id: 4,
        question: "निम्नलिखित में से कौन सा भारत का शास्त्रीय नृत्य नहीं है?",
        options: ["भरतनाट्यम", "कथक", "भांगड़ा", "कुचिपुड़ी"],
        correctAnswer: 2,
        explanation: "भांगड़ा एक लोक नृत्य है, न कि शास्त्रीय नृत्य। भारत के 8 शास्त्रीय नृत्य हैं।"
      },
      {
        id: 5,
        question: "भारत में कुल कितने राज्य हैं (2024)?",
        options: ["28", "29", "30", "31"],
        correctAnswer: 0,
        explanation: "2024 में भारत में 28 राज्य और 8 केंद्र शासित प्रदेश हैं।"
      },
      {
        id: 6,
        question: "भारत का राष्ट्रीय गान किसने लिखा?",
        options: ["रवींद्रनाथ टैगोर", "बंकिम चंद्र चटर्जी", "मुहम्मद इकबाल", "सरोजिनी नायडू"],
        correctAnswer: 0,
        explanation: "भारत का राष्ट्रीय गान 'जन गण मन' रवींद्रनाथ टैगोर ने लिखा।"
      },
      {
        id: 7,
        question: "भारत का राष्ट्रीय गीत कौन सा है?",
        options: ["जन गण मन", "वंदे मातरम", "सारे जहां से अच्छा", "जय जवान जय किसान"],
        correctAnswer: 1,
        explanation: "'वंदे मातरम' को भारत का राष्ट्रीय गीत माना जाता है, जिसे बंकिम चंद्र चटर्जी ने लिखा।"
      },
      {
        id: 8,
        question: "भारत में कुल कितने विश्व धरोहर स्थल हैं (2024)?",
        options: ["38", "40", "42", "44"],
        correctAnswer: 2,
        explanation: "2024 में भारत में 42 UNESCO विश्व धरोहर स्थल हैं।"
      },
      {
        id: 9,
        question: "भारत का सबसे बड़ा राज्य क्षेत्रफल के अनुसार कौन सा है?",
        options: ["महाराष्ट्र", "उत्तर प्रदेश", "राजस्थान", "मध्य प्रदेश"],
        correctAnswer: 2,
        explanation: "राजस्थान क्षेत्रफल के अनुसार भारत का सबसे बड़ा राज्य है।"
      },
      {
        id: 10,
        question: "भारत की जनसंख्या के अनुसार सबसे बड़ा राज्य कौन सा है?",
        options: ["महाराष्ट्र", "बिहार", "पश्चिम बंगाल", "उत्तर प्रदेश"],
        correctAnswer: 3,
        explanation: "उत्तर प्रदेश जनसंख्या के अनुसार भारत का सबसे बड़ा राज्य है।"
      },
      {
        id: 11,
        question: "भारत में कितनी धार्मिक अल्पसंख्यक समुदाय हैं?",
        options: ["4", "5", "6", "8"],
        correctAnswer: 2,
        explanation: "भारत में 6 धार्मिक अल्पसंख्यक समुदाय हैं: मुस्लिम, ईसाई, सिख, बौद्ध, पारसी और जैन।"
      },
      {
        id: 12,
        question: "भारत का राष्ट्रीय पशु कौन सा है?",
        options: ["शेर", "हाथी", "बाघ", "गाय"],
        correctAnswer: 2,
        explanation: "बाघ (Royal Bengal Tiger) भारत का राष्ट्रीय पशु है।"
      },
      {
        id: 13,
        question: "भारत का राष्ट्रीय पक्षी कौन सा है?",
        options: ["तोता", "मोर", "गरुड़", "कोयल"],
        correctAnswer: 1,
        explanation: "मोर (Indian Peafowl) भारत का राष्ट्रीय पक्षी है।"
      },
      {
        id: 14,
        question: "भारत का राष्ट्रीय फूल कौन सा है?",
        options: ["गुलाब", "कमल", "गेंदा", "चमेली"],
        correctAnswer: 1,
        explanation: "कमल (Lotus) भारत का राष्ट्रीय फूल है।"
      },
      {
        id: 15,
        question: "भारत का राष्ट्रीय वृक्ष कौन सा है?",
        options: ["पीपल", "बरगद", "नीम", "आम"],
        correctAnswer: 1,
        explanation: "बरगद (Banyan Tree) भारत का राष्ट्रीय वृक्ष है।"
      }
    ]
  },
  {
    id: "higher-education",
    name: "Higher Education System",
    nameHindi: "उच्च शिक्षा प्रणाली",
    description: "Test your knowledge about Indian higher education system",
    descriptionHindi: "भारतीय उच्च शिक्षा प्रणाली के बारे में अपने ज्ञान का परीक्षण करें",
    icon: "BookOpen",
    timeLimit: 20,
    questions: [
      {
        id: 1,
        question: "UGC का पूर्ण रूप क्या है?",
        options: ["University Grants Commission", "University General Council", "Union Government Commission", "University Guidance Council"],
        correctAnswer: 0,
        explanation: "UGC का पूर्ण रूप University Grants Commission है, जो भारत में उच्च शिक्षा का नियामक निकाय है।"
      },
      {
        id: 2,
        question: "NAAC का पूर्ण रूप क्या है?",
        options: ["National Assessment and Accreditation Council", "National Academic Accreditation Council", "National Authority for Academic Certification", "National Association for Academic Council"],
        correctAnswer: 0,
        explanation: "NAAC का पूर्ण रूप National Assessment and Accreditation Council है, जो UGC का स्वायत्त संस्थान है।"
      },
      {
        id: 3,
        question: "NIRF का पूर्ण रूप क्या है?",
        options: ["National Institutional Ranking Framework", "National Institute Ranking Forum", "National Indian Ranking Framework", "National Institutional Rating Framework"],
        correctAnswer: 0,
        explanation: "NIRF का पूर्ण रूप National Institutional Ranking Framework है, जो उच्च शिक्षा संस्थानों की रैंकिंग करता है।"
      },
      {
        id: 4,
        question: "भारत में विश्वविद्यालयों को कौन मान्यता देता है?",
        options: ["UGC", "AICTE", "MHRD", "NCERT"],
        correctAnswer: 0,
        explanation: "UGC (University Grants Commission) भारत में विश्वविद्यालयों को मान्यता देता है।"
      },
      {
        id: 5,
        question: "AICTE का पूर्ण रूप क्या है?",
        options: ["All India Council for Technical Education", "All India Committee for Technical Education", "All India Centre for Technical Education", "All India Council for Technology Education"],
        correctAnswer: 0,
        explanation: "AICTE का पूर्ण रूप All India Council for Technical Education है, जो तकनीकी शिक्षा का नियामक है।"
      },
      {
        id: 6,
        question: "भारत में सबसे पुराना विश्वविद्यालय कौन सा है?",
        options: ["दिल्ली विश्वविद्यालय", "मद्रास विश्वविद्यालय", "कलकत्ता विश्वविद्यालय", "मुंबई विश्वविद्यालय"],
        correctAnswer: 2,
        explanation: "कलकत्ता विश्वविद्यालय (1857) भारत में सबसे पुराना विश्वविद्यालय है।"
      },
      {
        id: 7,
        question: "भारत में कुल कितने केंद्रीय विश्वविद्यालय हैं (2024)?",
        options: ["45", "47", "49", "51"],
        correctAnswer: 2,
        explanation: "2024 में भारत में 49 केंद्रीय विश्वविद्यालय हैं।"
      },
      {
        id: 8,
        question: "IIT की स्थापना किस अधिनियम के तहत होती है?",
        options: ["IIT Act", "Institutes of Technology Act", "Indian Institutes of Technology Act", "Technical Education Act"],
        correctAnswer: 2,
        explanation: "IIT की स्थापना Institutes of Technology Act, 1961 के तहत होती है।"
      },
      {
        id: 9,
        question: "NCTE किस क्षेत्र का नियामक है?",
        options: ["तकनीकी शिक्षा", "शिक्षक शिक्षा", "चिकित्सा शिक्षा", "कृषि शिक्षा"],
        correctAnswer: 1,
        explanation: "NCTE (National Council for Teacher Education) शिक्षक शिक्षा का नियामक निकाय है।"
      },
      {
        id: 10,
        question: "भारत में उच्च शिक्षा में GER (Gross Enrollment Ratio) 2024 में क्या है?",
        options: ["लगभग 18%", "लगभग 28%", "लगभग 38%", "लगभग 48%"],
        correctAnswer: 1,
        explanation: "भारत में उच्च शिक्षा में GER 2024 में लगभग 28% है।"
      }
    ]
  },
  {
    id: "people-environment",
    name: "People & Environment",
    nameHindi: "मानव और पर्यावरण",
    description: "Test your knowledge about environmental studies",
    descriptionHindi: "पर्यावरण अध्ययन के बारे में अपने ज्ञान का परीक्षण करें",
    icon: "Leaf",
    timeLimit: 20,
    questions: [
      {
        id: 1,
        question: "विश्व पर्यावरण दिवस कब मनाया जाता है?",
        options: ["5 जून", "22 अप्रैल", "16 सितंबर", "2 अक्टूबर"],
        correctAnswer: 0,
        explanation: "विश्व पर्यावरण दिवस प्रत्येक वर्ष 5 जून को मनाया जाता है।"
      },
      {
        id: 2,
        question: "ओजोन परत किस वायुमंडलीय परत में स्थित है?",
        options: ["ट्रोपोस्फीयर", "स्ट्रैटोस्फीयर", "मीजोस्फीयर", "थर्मोस्फीयर"],
        correctAnswer: 1,
        explanation: "ओजोन परत स्ट्रैटोस्फीयर (लगभग 15-35 किमी ऊंचाई) में स्थित है।"
      },
      {
        id: 3,
        question: "निम्नलिखित में से कौन सा ग्रीनहाउस गैस नहीं है?",
        options: ["कार्बन डाइऑक्साइड", "मीथेन", "ऑक्सीजन", "नाइट्रस ऑक्साइड"],
        correctAnswer: 2,
        explanation: "ऑक्सीजन एक ग्रीनहाउस गैस नहीं है, जबकि CO2, CH4 और N2O ग्रीनहाउस गैसें हैं।"
      },
      {
        id: 4,
        question: "IPCC का पूर्ण रूप क्या है?",
        options: ["Intergovernmental Panel on Climate Change", "International Panel on Climate Change", "Intergovernmental Program on Climate Change", "International Program on Climate Control"],
        correctAnswer: 0,
        explanation: "IPCC का पूर्ण रूप Intergovernmental Panel on Climate Change है।"
      },
      {
        id: 5,
        question: "भारत का राष्ट्रीय पक्षी मोर किस परिवार से संबंधित है?",
        options: ["फ़ीज़ेंट", "फ़िंच", "फ़ैल्कन", "फ़्लेमिंगो"],
        correctAnswer: 0,
        explanation: "भारतीय मोर (Indian Peafowl) फ़ीज़ेंट (Phasianidae) परिवार से संबंधित है।"
      },
      {
        id: 6,
        question: "निम्नलिखित में से कौन सा जैविक विविधता का 'हॉटस्पॉट' नहीं है?",
        options: ["पश्चिमी घाट", "हिमालय", "थार रेगिस्तान", "पूर्वी हिमालय"],
        correctAnswer: 2,
        explanation: "थार रेगिस्तान जैविक विविधता का हॉटस्पॉट नहीं है, जबकि पश्चिमी घाट और हिमालय हैं।"
      },
      {
        id: 7,
        question: "पेरिस समझौता किस वर्ष हुआ?",
        options: ["2014", "2015", "2016", "2017"],
        correctAnswer: 1,
        explanation: "पेरिस समझौता 2015 में हुआ, जो जलवायु परिवर्तन से निपटने के लिए एक अंतरराष्ट्रीय समझौता है।"
      },
      {
        id: 8,
        question: "भारत में सबसे बड़ा राष्ट्रीय उद्यान कौन सा है?",
        options: ["काजीरंगा", "हेमिस", "जिम कॉर्बेट", "सुंदरबन"],
        correctAnswer: 1,
        explanation: "हेमिस राष्ट्रीय उद्यान (लद्दाख) क्षेत्रफल के अनुसार भारत का सबसे बड़ा राष्ट्रीय उद्यान है।"
      },
      {
        id: 9,
        question: "निम्नलिखित में से कौन सा नवीकरणीय ऊर्जा स्रोत नहीं है?",
        options: ["सौर ऊर्जा", "पवन ऊर्जा", "कोयला", "जल ऊर्जा"],
        correctAnswer: 2,
        explanation: "कोयला एक अनवीकरणीय (non-renewable) ऊर्जा स्रोत है।"
      },
      {
        id: 10,
        question: "भारत में Project Tiger कब शुरू हुआ?",
        options: ["1971", "1973", "1975", "1977"],
        correctAnswer: 1,
        explanation: "Project Tiger 1973 में शुरू हुआ था, जो बाघों के संरक्षण के लिए एक पहल है।"
      }
    ]
  },
  {
    id: "data-interpretation",
    name: "Data Interpretation",
    nameHindi: "डेटा व्याख्या",
    description: "Test your data analysis and interpretation skills",
    descriptionHindi: "अपने डेटा विश्लेषण और व्याख्या कौशल का परीक्षण करें",
    icon: "BarChart3",
    timeLimit: 20,
    questions: [
      {
        id: 1,
        question: "यदि किसी कक्षा में 40 छात्र हैं और 60% लड़कियां हैं, तो लड़कों की संख्या कितनी है?",
        options: ["14", "16", "18", "20"],
        correctAnswer: 1,
        explanation: "60% लड़कियां = 24 लड़कियां, इसलिए लड़के = 40 - 24 = 16"
      },
      {
        id: 2,
        question: "किसी संख्या का 20% उसी संख्या के 15% से 10 अधिक है। वह संख्या क्या है?",
        options: ["100", "150", "200", "250"],
        correctAnswer: 2,
        explanation: "माना संख्या x है। 0.20x - 0.15x = 10, इसलिए 0.05x = 10, x = 200"
      },
      {
        id: 3,
        question: "यदि A:B = 2:3 और B:C = 4:5, तो A:C = ?",
        options: ["8:15", "6:15", "8:9", "4:5"],
        correctAnswer: 0,
        explanation: "A:B = 2:3 = 8:12 और B:C = 4:5 = 12:15, इसलिए A:C = 8:15"
      },
      {
        id: 4,
        question: "किसी वस्तु को 20% लाभ पर बेचा जाता है। यदि क्रय मूल्य 25% कम होता, तो लाभ प्रतिशत क्या होता?",
        options: ["50%", "60%", "70%", "80%"],
        correctAnswer: 1,
        explanation: "माना CP = 100, SP = 120। नया CP = 75, SP = 120, लाभ = 45, लाभ% = 45/75 × 100 = 60%"
      },
      {
        id: 5,
        question: "5, 8, 11, 14, 17, ... श्रृंखला में अगली संख्या क्या है?",
        options: ["19", "20", "21", "22"],
        correctAnswer: 1,
        explanation: "यह एक समांतर श्रेढ़ी है जिसमें प्रत्येक संख्या में 3 जोड़ा जाता है: 17 + 3 = 20"
      },
      {
        id: 6,
        question: "यदि किसी संख्या का वर्गमूल 16 है, तो उस संख्या का घन कितना होगा?",
        options: ["4096", "512", "256", "65536"],
        correctAnswer: 3,
        explanation: "संख्या = 16² = 256, घन = 256³ = 16,777,216 या वैकल्पिक रूप से 16⁶ = 16,777,216"
      },
      {
        id: 7,
        question: "एक आयत की लंबाई और चौड़ाई का अनुपात 3:2 है। यदि परिमाप 50 सेमी है, तो क्षेत्रफल क्या है?",
        options: ["100 वर्ग सेमी", "150 वर्ग सेमी", "200 वर्ग सेमी", "250 वर्ग सेमी"],
        correctAnswer: 1,
        explanation: "माना लंबाई = 3x, चौड़ाई = 2x। परिमाप = 2(3x+2x) = 10x = 50, x = 5। क्षेत्रफल = 15 × 10 = 150"
      },
      {
        id: 8,
        question: "यदि 8 व्यक्ति 10 दिनों में काम पूरा करते हैं, तो 5 व्यक्ति उसी काम को कितने दिनों में पूरा करेंगे?",
        options: ["12 दिन", "14 दिन", "16 दिन", "18 दिन"],
        correctAnswer: 2,
        explanation: "M1 × D1 = M2 × D2, 8 × 10 = 5 × D2, D2 = 80/5 = 16 दिन"
      },
      {
        id: 9,
        question: "यदि किसी संख्या का 1/3 उसी संख्या के 1/4 से 5 अधिक है, तो वह संख्या क्या है?",
        options: ["40", "50", "60", "70"],
        correctAnswer: 2,
        explanation: "माना संख्या x है। x/3 - x/4 = 5, (4x-3x)/12 = 5, x = 60"
      },
      {
        id: 10,
        question: "एक त्रिभुज की भुजाएं 3:4:5 के अनुपात में हैं। यदि परिमाप 36 सेमी है, तो सबसे बड़ी भुजा क्या है?",
        options: ["12 सेमी", "15 सेमी", "18 सेमी", "20 सेमी"],
        correctAnswer: 1,
        explanation: "माना भुजाएं 3x, 4x, 5x हैं। परिमाप = 12x = 36, x = 3। सबसे बड़ी भुजा = 5 × 3 = 15 सेमी"
      }
    ]
  }
];

export const getCategoryById = (id: string): QuizCategory | undefined => {
  return quizCategories.find(category => category.id === id);
};

export const getTotalQuestions = (): number => {
  return quizCategories.reduce((total, category) => total + category.questions.length, 0);
};
