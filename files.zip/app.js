// Multiple AI Chat - Demo
// Author: Generated for historynetexpress-max (Hindi/English comments)
// This demo simulates multiple AI models and provides a UI with:
// - Top pill selection bar (horizontal scroll with buttons)
// - Floating bar with model cards (horizontal scroll with buttons)
// - Chat area + composer with single/multi-send support
// Integrate real AI APIs by replacing `simulateModelResponse` with fetch() to model endpoints.

// List of models to show
const MODELS = [
  { id: 'chatgpt', name: 'ChatGPT', desc: 'OpenAI GPT-based assistant' },
  { id: 'gemini', name: 'Gemini', desc: 'Google Gemini' },
  { id: 'copilot', name: 'Copilot', desc: 'GitHub Copilot-like assistant' },
  { id: 'grok', name: 'Grok', desc: 'Groq/Grok-style model' },
  { id: 'perplexity', name: 'Perplexity', desc: 'Perplexity.ai style search assistant' },
  { id: 'deepseek', name: 'DeepSeek', desc: 'Deep-seeking retrieval model' },
  { id: 'kimi', name: 'Kimi', desc: 'Kimi conversational AI' },
  { id: 'googleai', name: 'Google AI Studio', desc: 'Google AI Studio model' },
];

// State
let activeTop = 'all';    // top pill selection (could be category)
let selectedModels = new Set(['chatgpt']); // which model cards are selected
let multiMode = false;

// Elements
const topBar = document.getElementById('topBar');
const floatingBar = document.getElementById('floatingBar');
const chatEl = document.getElementById('chat');
const modeSelect = document.getElementById('modeSelect');
const composer = document.getElementById('composer');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const multiSendToggle = document.getElementById('multiSendToggle');

// Helper: create top pills
const topPills = [
  { id: 'all', label: 'All' },
  { id: 'conversational', label: 'Conversational' },
  { id: 'coding', label: 'Coding' },
  { id: 'search', label: 'Search' },
  { id: 'experimental', label: 'Experimental' },
];

function renderTopBar() {
  topBar.innerHTML = '';
  topPills.forEach(p => {
    const btn = document.createElement('button');
    btn.className = 'pill' + (p.id === activeTop ? ' active' : '');
    btn.textContent = p.label;
    btn.onclick = () => {
      activeTop = p.id;
      renderTopBar();
      // Optionally filter floating bar models based on category
      // For demo, just highlight selection
    };
    topBar.appendChild(btn);
  });
}

// Helper: render floating model cards
function renderFloatingBar() {
  floatingBar.innerHTML = '';
  MODELS.forEach(m => {
    const card = document.createElement('div');
    card.className = 'card';
    const h = document.createElement('h4'); h.textContent = m.name;
    const p = document.createElement('p'); p.textContent = m.desc;
    const controls = document.createElement('div'); controls.className = 'controls';

    const selectBtn = document.createElement('button');
    selectBtn.className = selectedModels.has(m.id) ? 'selected' : 'select';
    selectBtn.textContent = selectedModels.has(m.id) ? 'Selected' : 'Select';
    selectBtn.onclick = () => {
      if (selectedModels.has(m.id)) selectedModels.delete(m.id);
      else selectedModels.add(m.id);
      syncSelectToUI();
      renderFloatingBar();
    };

    const demoBtn = document.createElement('button');
    demoBtn.className = 'select';
    demoBtn.textContent = 'Preview';
    demoBtn.onclick = () => {
      addSystemMessage(`Preview from ${m.name}`, `This is a preview reply by ${m.name}.`);
    };

    controls.appendChild(selectBtn);
    controls.appendChild(demoBtn);

    card.appendChild(h);
    card.appendChild(p);
    card.appendChild(controls);

    floatingBar.appendChild(card);
  });

  // Also populate the single-select dropdown
  modeSelect.innerHTML = '';
  MODELS.forEach(m=>{
    const opt = document.createElement('option');
    opt.value = m.id;
    opt.textContent = m.name;
    modeSelect.appendChild(opt);
  });
  // Set dropdown to first selected model or fallback
  const firstSel = [...selectedModels][0] || MODELS[0].id;
  modeSelect.value = firstSel;
}

// Sync selected models with UI elements if needed
function syncSelectToUI(){
  // Update multi toggle text
  multiMode = multiMode && selectedModels.size > 1 ? true : multiMode;
  multiSendToggle.classList.toggle('active', multiMode);
}

// Chat helpers
function addUserMessage(text){
  const msg = document.createElement('div');
  msg.className = 'msg user';
  msg.textContent = text;
  chatEl.appendChild(msg);
  chatEl.scrollTop = chatEl.scrollHeight;
}

function addBotMessage(modelId, text){
  const modelName = (MODELS.find(m=>m.id===modelId)||{name:modelId}).name;
  const wrapper = document.createElement('div');
  wrapper.className = 'msg bot';
  const meta = document.createElement('div'); meta.className='meta';
  meta.textContent = `${modelName} • ${new Date().toLocaleTimeString()}`;
  const body = document.createElement('div'); body.className='body';
  body.textContent = text;
  wrapper.appendChild(meta);
  wrapper.appendChild(body);
  chatEl.appendChild(wrapper);
  chatEl.scrollTop = chatEl.scrollHeight;
}

// Add system/preview message
function addSystemMessage(title, text){
  const wrapper = document.createElement('div');
  wrapper.className = 'msg bot';
  const meta = document.createElement('div'); meta.className='meta';
  meta.textContent = `System • ${new Date().toLocaleTimeString()}`;
  const h = document.createElement('div'); h.style.fontWeight='700'; h.textContent = title;
  const body = document.createElement('div'); body.textContent = text;
  wrapper.appendChild(meta);
  wrapper.appendChild(h);
  wrapper.appendChild(body);
  chatEl.appendChild(wrapper);
  chatEl.scrollTop = chatEl.scrollHeight;
}

// Simulate streaming response from a model (replace with real API calls)
function simulateModelResponse(modelId, userText){
  // Return promise that resolves after streaming simulation
  return new Promise(resolve=>{
    const snippets = [
      `Processing: "${userText.slice(0,30)}..."`,
      `Thoughts: analyzing context...`,
      `Result: ${userText.split('').reverse().slice(0,120).join('')}`,
    ];
    // Make the bot message element first with typing effect
    const modelName = (MODELS.find(m=>m.id===modelId)||{name:modelId}).name;
    const wrapper = document.createElement('div');
    wrapper.className = 'msg bot';
    const meta = document.createElement('div'); meta.className='meta';
    meta.textContent = `${modelName} • ${new Date().toLocaleTimeString()}`;
    const body = document.createElement('div'); body.className='body';
    wrapper.appendChild(meta);
    wrapper.appendChild(body);
    chatEl.appendChild(wrapper);
    chatEl.scrollTop = chatEl.scrollHeight;

    // Simulate streaming by appending text gradually
    let i = 0;
    const interval = setInterval(()=>{
      body.textContent = (body.textContent ? body.textContent + '\n' : '') + snippets[i];
      i++;
      chatEl.scrollTop = chatEl.scrollHeight;
      if (i>=snippets.length){
        clearInterval(interval);
        // minor post-processing to make it feel model-specific
        const flavor = modelFlavor(modelId);
        body.textContent = body.textContent + '\n\n' + flavor;
        resolve();
      }
    }, 600 + Math.random()*600);
  });
}

function modelFlavor(modelId){
  switch(modelId){
    case 'gemini': return '— Gemini style concise summary.';
    case 'chatgpt': return '— ChatGPT-like helpful reply.';
    case 'copilot': return '— Copilot: code-suggestion oriented.';
    case 'grok': return '— Grok: fast, factual.';
    case 'perplexity': return '— Perplexity: cites sources (demo).';
    case 'deepseek': return '— DeepSeek: retrieval-augmented answer.';
    case 'kimi': return '— Kimi: friendly conversational tone.';
    case 'googleai': return '— Google AI Studio: studio-tuned output.';
    default: return '— Generic model reply.';
  }
}

// Handle composer submit
composer.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const text = messageInput.value.trim();
  if (!text) return;
  addUserMessage(text);
  messageInput.value = '';
  // Determine targets
  if (multiMode && selectedModels.size>0){
    // send to each selected model in parallel (simulated)
    const promises = [...selectedModels].map(mid => simulateModelResponse(mid, text));
    await Promise.all(promises);
  } else {
    const mid = modeSelect.value || [...selectedModels][0] || MODELS[0].id;
    await simulateModelResponse(mid, text);
  }
});

// Toggle multi mode (send to all selected models)
multiSendToggle.addEventListener('click', () => {
  multiMode = !multiMode;
  multiSendToggle.classList.toggle('active', multiMode);
  multiSendToggle.textContent = multiMode ? 'Multi ✓' : 'Multi';
});

// Keyboard handling for Enter to send, Shift+Enter newline
messageInput.addEventListener('keydown', (e)=>{
  if (e.key === 'Enter' && !e.shiftKey){
    e.preventDefault();
    sendBtn.click();
  }
});

// Scroll button handlers
document.querySelectorAll('.scroll-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const targetId = btn.dataset.target;
    const el = document.getElementById(targetId);
    if (!el) return;
    const amount = el.clientWidth * 0.6;
    if (btn.classList.contains('left')){
      el.scrollBy({left:-amount, behavior:'smooth'});
    } else {
      el.scrollBy({left:amount, behavior:'smooth'});
    }
  });
});

// Initialize UI
function init(){
  renderTopBar();
  renderFloatingBar();
  syncSelectToUI();

  // demo welcome message
  addSystemMessage('Welcome', 'यह एक डेमो चैट इंटरफ़ेस है जहाँ आप मल्टीपल AI मॉडल्स चुन सकते हैं। मॉडल कार्ड पर Select करके उन्हें सक्रिय करें, फिर Message लिखकर Send करें।');

  // click handlers to allow clicking pill or card to focus selection
  topBar.addEventListener('click', (e)=>{
    if (e.target.matches('.pill')) e.target.focus();
  });

  // make floating bar horizontally scrollable by dragging (nice UX)
  makeDragScrollable(document.getElementById('floatingBar'));
  makeDragScrollable(document.getElementById('topBar'));
}

// Utility: enable pointer drag to scroll for nicer UX
function makeDragScrollable(container){
  let isDown=false, startX, scrollLeft;
  container.addEventListener('mousedown', (e)=>{
    isDown=true;
    container.classList.add('active');
    startX = e.pageX - container.offsetLeft;
    scrollLeft = container.scrollLeft;
    e.preventDefault();
  });
  window.addEventListener('mouseup', ()=>{isDown=false; container.classList.remove('active')});
  container.addEventListener('mousemove', (e)=>{
    if(!isDown) return;
    const x = e.pageX - container.offsetLeft;
    const walk = (x - startX) * 1; // scroll-fast
    container.scrollLeft = scrollLeft - walk;
  });
}

// Start
init();

/*
Integration notes (where to plug real APIs):
- Replace simulateModelResponse(modelId, userText) with a function that calls your backend/API.
  Example pattern:
    1) POST to your server: { model: modelId, prompt: userText }
    2) Server calls provider API keys (OpenAI, Google, etc.)
    3) Server streams or returns response chunks -> update the body element progressively.

- If you want multi-model parallel queries, ensure you handle billing/rate limits properly.

- For real-time streaming: use fetch with ReadableStream or server-sent events (SSE), and append chunks to the DOM as they arrive.

Security:
- Never embed provider API keys in front-end. Use a backend proxy.
*/